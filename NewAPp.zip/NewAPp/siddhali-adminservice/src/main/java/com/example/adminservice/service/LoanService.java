package com.example.adminservice.service;

import java.util.List;

import com.example.adminservice.models.Loan_details;

public interface LoanService {
	public List<Loan_details> listLoans();
}
